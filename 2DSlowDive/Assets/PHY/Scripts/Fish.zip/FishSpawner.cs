using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishSpawner : MonoBehaviour
{
    [SerializeField] private List<GameObject> fishPrefabs;      // �̰� ���߿� ����Ư�� �����ؼ� �ҰŶ� ex) ����: ��ġ����, ����: ��¡�� ����, �븣�����ؿ�: �������� ��

    [SerializeField] private SpawnerConfigSO spawnerConfig;

    private readonly List<GameObject> aliveFish = new();

    private Coroutine spawnRoutine;
    private void Start()
    { 
        StartSpawn();
    }

    public void StartSpawn()
    {
        if (spawnRoutine != null)
        {
            StopCoroutine(spawnRoutine);
        }
        spawnRoutine = StartCoroutine(FishSpawn());
    }

    public IEnumerator FishSpawn()
    {
        while (true)
        {
            yield return new WaitForSeconds(spawnerConfig.fishInterval);

            for(int i = aliveFish.Count - 1; i >= 0; i--)
            {
                if(aliveFish[i] == null)
                    aliveFish.RemoveAt(i);
            }

            if (aliveFish.Count >= spawnerConfig.maxFishSpawn)
                continue;

            GameObject randomFish = fishPrefabs[Random.Range(0, fishPrefabs.Count)];

            Vector2 randomPos = new Vector2(transform.position.x + Random.Range(-spawnerConfig.fishSpawnX, spawnerConfig.fishSpawnX), transform.position.y + Random.Range(-spawnerConfig.fishSpawnY, spawnerConfig.fishSpawnY));

            Instantiate(randomFish, randomPos, randomFish.transform.rotation);
        }
    }

    public void ResetSpawn()
    {
        if(spawnRoutine != null)
        {
            StopCoroutine(spawnRoutine);
            spawnRoutine = null;
        }

        for (int i = aliveFish.Count -1; i>=0; i--)
        {
            if (aliveFish[i]==null)
            {
                Destroy(aliveFish[i]);
            }
            aliveFish.Clear();

            spawnRoutine = StartCoroutine(FishSpawn());
        }
    }
}
