using System.Collections.Generic;
using UnityEngine;

public class FishDataLoader : MonoBehaviour
{
    public static FishDataLoader Instance { get; private set; }

    [System.Serializable]
    public class FishInfo
    {
        public FishType fishType;
        public string worldSpritePath;
        public string iconSpriteName;   // �߰�: ��ǥ ������ sprite �̸�
        public string description;
    }

    [System.Serializable]
    public class FishList
    {
        public List<FishInfo> fishList = new();
    }

    private Dictionary<FishType, FishInfo> fishInfoDict;

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        LoadFishData();
    }

    private void LoadFishData()
    {
        TextAsset jsonFile = Resources.Load<TextAsset>("fish_data");
        if (jsonFile == null)
        {
            Debug.LogError("[FishDataLoader] fish_data.json�� Resources �������� ã�� �� ����");
            return;
        }

        FishList loadedList = JsonUtility.FromJson<FishList>(jsonFile.text);

        if (loadedList == null || loadedList.fishList == null)
        {
            Debug.LogError("[FishDataLoader] fish_data.json �Ľ� ���� �Ǵ� fishList null");
            return;
        }

        fishInfoDict = new Dictionary<FishType, FishInfo>(loadedList.fishList.Count);

        foreach (var info in loadedList.fishList)
        {
            fishInfoDict[info.fishType] = info;
        }

        // ���� ����
        foreach (FishType type in System.Enum.GetValues(typeof(FishType)))
        {
            if (!fishInfoDict.ContainsKey(type))
                Debug.LogError($"[FishDataLoader] JSON ������ ����: {type} ({(int)type})");
        }

        Debug.Log($"[FishDataLoader] �ε� �Ϸ� ({fishInfoDict.Count}��)");
    }

    public FishInfo GetFishInfo(FishType fishType)
    {
        if (fishInfoDict == null)
        {
            Debug.LogWarning("[FishDataLoader] �����Ͱ� �ε���� ����");
            return null;
        }

        if (fishInfoDict.TryGetValue(fishType, out FishInfo info))
            return info;

        return null;
    }
}
