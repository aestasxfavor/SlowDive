using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;


public class FishInventoryService : MonoBehaviour
{
    public static FishInventoryService Instance;
    public event Action OnInventoryChanged;

    private FishInventoryData inventoryData;
    private CodexService codexService;

    public int CurrentDiveCaughtCount { get; private set; }
    public int CurrentDiveNewDiscoveryCount {  get; private set; }

    private readonly Dictionary<FishType, Sprite> fishSpriteCache = new(128);

    private void Awake()
    {

        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        inventoryData = GameManager.Instance.GetStorageInventoryData();
    }

    private FishInventoryData Data
    {
        get
        {
            if (inventoryData == null)
            {
                inventoryData = GameManager.Instance?.GetStorageInventoryData();
            }
            return inventoryData;
        }
    }

    public void Init(CodexService service)
    {
        codexService = service;
    }


    public void AddFish(FishType fishType)
    {
        var storageData = Data;
        if (storageData == null)
        {
            return;
        }

        storageData.AddFish(fishType);

        // �̹� ������� ȸ���� ��ü ������ ��
        CurrentDiveCaughtCount++;

        // �űԾ����̸� true, �̹� �߰��� �����̸� false
        bool isNewDiscovery = codexService?.Registerfish(fishType) ?? false;

        if (isNewDiscovery) CurrentDiveNewDiscoveryCount++;

        //codexService?.RegisterFish(fishType);

        OnInventoryChanged?.Invoke();
    }

    public void ResetDiveResult()
    {
        CurrentDiveCaughtCount = 0;
        CurrentDiveNewDiscoveryCount = 0;
    }

    public Sprite GetFishSprite(FishType fishType)
    {
        if (fishSpriteCache.TryGetValue(fishType, out var sprite))
        {
            return sprite;

        }
        sprite = LoadFishSprite(fishType);

        if (sprite != null)
            fishSpriteCache[fishType] = sprite;

        return sprite;
    }

    private Sprite LoadFishSprite(FishType fishType)
    {
        var loader = FishDataLoader.Instance;
        if (loader == null) return null;

        var fishInfo = loader.GetFishInfo(fishType);
        if (fishInfo == null) return null;

        if (string.IsNullOrEmpty(fishInfo.worldSpritePath))
            return null;

        var sprites = Resources.LoadAll<Sprite>(fishInfo.worldSpritePath);
        if (sprites == null || sprites.Length == 0)
        { 
            return null;
        }

        // JSON�� iconSpriteName�� ������ �װɷ� ���� ����
        if (!string.IsNullOrEmpty(fishInfo.iconSpriteName))
        {
            for (int i = 0; i < sprites.Length; i++)
            {
                var sprite = sprites[i];
                if (sprite != null && sprite.name == fishInfo.iconSpriteName)
                    return sprite;
            }

            // Debug.LogError($"[FishInventoryService] target sprite not found: {fishInfo.iconSpriteName} / path={fishInfo.worldSpritePath}");
            return null;
        }

        // iconSpriteName ������ fallback (����� ���)
        //Debug.LogWarning($"[FishInventoryService] iconSpriteName ������� �� fallback sprites[0] ��� (fishType={fishType})");
        return sprites[0];
    }

    public void SetInventoryData(FishInventoryData data)
    {
        inventoryData = data;
        OnInventoryChanged?.Invoke();
    }

    /// <summary>
    /// IReadOnlyList: �б� ���� ����Ʈ �������̽� 
    /// ������ ����� �����ֱ� ���� �����͸� �ѱ�� ���� ���
    /// </summary>
    /// <returns></returns>
    public IReadOnlyList<FishViewData> GetFishViewList()
    {
        var inventoryData = Data;
        if (inventoryData == null) return null;

        var result = new List<FishViewData>();

        foreach (var slot in inventoryData.caughtFishList)
        {
            if (slot == null) continue;

            result.Add(new FishViewData(slot.fishType, slot.count));
        }

        return result;
    }

    #region ������ ���� ��ȯ ����
    public int CalculateTotalCoin()  // ������ ����Լ�
    {
        var inventoryData = Data;
        if (inventoryData == null) return 0;
        int total = 0;
        foreach (var fish in inventoryData.caughtFishList)
        {
            if (fish == null) continue;
            total += fish.count;
        }

        return total * 10;
    }

    public int ExchangeAllFishToCoin()     // ��ȯ���� �Լ�
    {
     
        // 1. ���� ������ �� ����ϱ�
        int coin = CalculateTotalCoin();

        // 2. ���� ������ ���� ����
        inventoryData.caughtFishList.Clear();

        // 3. ���� ������Ű��
        CoinService.Instance.AddCoin(coin);
        // 4. �����ϱ� 
        SaveManager.Instance.RequestSave();

        return coin;
    }
    #endregion
}