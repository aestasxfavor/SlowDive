using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ShopUI : MonoBehaviour
{
    [Header("Tab Buttons")]
    [SerializeField] private Button coinTabButton;
    [SerializeField] private Button shopTabButton;

    [Header("Tab Roots")]
    [SerializeField] private GameObject coinTabRoot;
    [SerializeField] private GameObject shopTabRoot;

    [Header("Coin Exchange")]
    [SerializeField] private Transform coinGridRoot;
    [SerializeField] private GameObject fishToCoinSlotPrefab;
    [SerializeField] private Sprite emptySprite;

    [SerializeField] private TextMeshProUGUI amountText;
    [SerializeField] private TextMeshProUGUI harpoonCoinText;

    private PopupManager popupManager;

    private const int RequiredCoin = 1500;

    private void Awake()
    {
        coinTabButton.onClick.AddListener(OpenCoinTab);
        shopTabButton.onClick.AddListener(OpenShopTab);
    }

    private void Start()
    {
        UpdateCoinUI();
    }
    #region Debug Only (������ ���� �׽�Ʈ)
#if UNITY_EDITOR
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            DebugAddCoin();
        }
    }

    private void DebugAddCoin()
    {
        CoinService.Instance.AddCoin(5000);
        UpdateCoinUI();
        Debug.Log("�׽�Ʈ ���� ���� �Ϸ�");
    }
#endif
    #endregion

    public void Init(PopupManager _popupManager)
    {
        popupManager = _popupManager;
    }


    // ���� ���� �� �⺻ ����
    public void Open()
    {
        OpenCoinTab();
    }

    public void OpenCoinTab()
    {
        Debug.Log("������ ��ȯ");
        coinTabRoot.SetActive(true);
        shopTabRoot.SetActive(false);

        BuildInventorySlots();
        amountText.text = FishInventoryService.Instance.CalculateTotalCoin().ToString();
    }

    public void OpenShopTab()
    {
        Debug.Log("������ ��ȯ");
        coinTabRoot.SetActive(false);
        shopTabRoot.SetActive(true);
    }

    public void BuildInventorySlots()
    {
        // 1. ���� ���� ����
        foreach (Transform child in coinGridRoot)
        {
            Destroy(child.gameObject);
        }
        // 2. ������ ������ �������� (fishInventoryService ����)
        var service = FishInventoryService.Instance;
        if (service == null) return;

        var fishList = service.GetFishViewList();
        if (fishList == null) return;

        // 3. ���� �����ϱ� (���� ���� ����)
        Dictionary<FishType, int> inventoryMap = new();
        foreach (var fish in fishList)
        {
            inventoryMap[fish.fishType] = fish.count;
        }

        int totalSlotCount = 12; // Todo: SO�� �и��Ͽ� ���ϴ� ��ŭ ������ �ø� �� ����
        FishType[] fishTypes = (FishType[])System.Enum.GetValues(typeof(FishType));

        for (int i = 0; i < totalSlotCount; i++)
        {
            GameObject obj = Instantiate(fishToCoinSlotPrefab, coinGridRoot);
            FishToCoinSlot slot = obj.GetComponent<FishToCoinSlot>();

            if (i < fishTypes.Length)
            {
                FishType fishType = fishTypes[i];

                if (inventoryMap.TryGetValue(fishType, out int count) && count > 0)
                {
                    Sprite icon = service.GetFishSprite(fishType);
                    if (icon != null)
                    {
                        slot.Set(icon, count, fishType);
                    }
                    else
                    {
                        slot.SetEmpty(emptySprite);
                    }
                }
                else
                {
                    slot.SetEmpty(emptySprite);
                }
            }
            else
            {
                slot.SetEmpty(emptySprite);
            }
        }

    }

    public void OnClickExchange()
    {
        popupManager.ShowExchange(ExchangeFishToCoin);
    }

    public void ExchangeFishToCoin()
    {
        var service = FishInventoryService.Instance;
        if (service == null) return;

        int gained = service.CalculateTotalCoin();

        service.ExchangeAllFishToCoin();

        BuildInventorySlots();
        amountText.text = $"{gained:N0}��";

        UpdateCoinUI();

    }

    public void UpdateCoinUI()
    {
        int current = CoinService.Instance.CurrentCoin;
        harpoonCoinText.text = $"{current} / {RequiredCoin} ��";
    }

    public void BuyHarpoonUpgrade()
    {
        Debug.Log("���Ź�ư ȣ���");
        popupManager.ShowBuyCheck(BuyHarppon);
    }

    private void BuyHarppon()
    {
        Debug.Log("BuyHarppon ����");

        int current = CoinService.Instance.CurrentCoin;
        Debug.Log("���� ����: " + current);

        if (current < RequiredCoin)
        {
            Debug.Log("���� ���� �˾�");
            popupManager.ShowCoinFail();
            return;
        }

        if (SaveManager.Instance.HasHarpoonUpgrade())
        {
            Debug.Log("�̹� ���� �˾�");
            popupManager.ShowHasHarpoon();
            return;
        }

        Debug.Log("���� ����");

        CoinService.Instance.SpendCoin(RequiredCoin);
        SaveManager.Instance.SetHarpoonUpgrade(true);

        UpdateCoinUI();
    }
}