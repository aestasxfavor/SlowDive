using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UISlot : MonoBehaviour
{
    [SerializeField] private Image itemIcon;      // ������ �̹���
    [SerializeField] private TMP_Text countText;  // x2, x3 ǥ���� �ؽ�Ʈ

    public bool IsEmpty => isEmpty;
    public FishType FishType => fishType;
    public Sprite CurrentSprite => itemIcon.sprite;

    private bool isEmpty = true;
    private FishType fishType;   // �� ���Կ� ����ִ� ������ ����
    private int count = 0;

    private void Awake()
    {
        Clear();    // ������ �� ���� �� ����
    }

    // �� ������ ���� �� (ù ����)
    public void SetItem(Sprite icon, FishType type, int newCount)
    {
        fishType = type;
        isEmpty = false;

        if (itemIcon != null)
        {
            itemIcon.sprite = icon;
            itemIcon.enabled = icon != null;

#if UNITY_EDITOR
            Debug.Log($"[UISlot] {type} ������ ���� {(icon != null ? icon.name : "NULL")}");
#endif
        }

        count = Mathf.Max(1, newCount);
        UpdateCountText();
    }

    private void UpdateCountText()
    {
        //if (countText == null) return;

        //if (count <= 1)
        //    countText.text = "";          // 1������ �� ���� ����
        //else
        //    countText.text = count.ToString(); // x2, x3 ...

        if (countText == null) return;

        if (count <= 1)
        {
            countText.enabled = false;
        }
        else
        {
            countText.enabled = true;
            countText.text = count.ToString();
        }
    }

    // ���� ���� (���߿� �� �� ������ ���)
    public void Clear()
    {
        isEmpty = true;
        fishType = default;
        count = 0;

        if (itemIcon != null)
        {
            itemIcon.sprite = null;
            itemIcon.enabled = false;
        }

        if (countText != null)
        {
            countText.text = "";
            countText.enabled = false;
        }
    }

    public void CodexDiscover(Sprite icon)
    {
        isEmpty = false; 
        if(itemIcon != null)
        {
            itemIcon.sprite = icon;
            itemIcon.enabled = true;
            itemIcon.color = Color.white;
        }

        if (countText != null)
            countText.enabled = false;
    }

    public void CodexUndiscover(Sprite unknownIcon)
    {
        isEmpty = true;

        if (itemIcon != null)
        {
            itemIcon.sprite = unknownIcon;
            itemIcon.enabled = true;
            itemIcon.color = new Color(0, 0, 0, 0.4f);
        }

        if (countText != null)
            countText.enabled = false;
    }
}
