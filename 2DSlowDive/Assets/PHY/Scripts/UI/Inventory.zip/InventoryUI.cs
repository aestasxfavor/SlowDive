using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;

public class InventoryUI : MonoBehaviour, UIClosable
{
    private FishInventoryData sharedInventoryData;

    [Header("���� �θ� ������Ʈ")]
    [SerializeField] private GameObject inventoryPanelRoot;
    [SerializeField] private Transform quickbarParent;
    [SerializeField] private Transform inventoryParent;

    [Header("���� ������")]
    [SerializeField] private GameObject slotPrefab;

    [Header("���� ����")]
    [SerializeField] private InventoryConfigSO inventoryConfig;

    private readonly List<UISlot> quickbarSlots = new();
    private readonly List<UISlot> inventorySlots = new();

    private PlayerCtrls playerCtrls;
    private bool isInventoryOpen = false;
    private bool isSlotsCreated = false;

    // GameManager���� ���� ������ ���� �� �ٷ� UI ����
    public void SetInventoryData(FishInventoryData data)
    {
        sharedInventoryData = data;

        // ������ ���� ���� ���̸� Start���� Refresh �� �Ŷ� ���⼱ ����
        if (!isSlotsCreated) return;

        RefreshUI();
    }

    private void Awake()
    {
        playerCtrls = new PlayerCtrls();
        playerCtrls.Player.Inventory.performed += OnInventoryInput; // ����
        playerCtrls.Enable();
    }

    private void OnInventoryInput(InputAction.CallbackContext _)
    {
        ToggleInventory();
    }

    private void OnEnable()
    {
        SceneFlowManager.Instance?.Register(this);

        if (FishInventoryService.Instance != null)
            FishInventoryService.Instance.OnInventoryChanged += RefreshUI; // �̺�Ʈ ����
    }

    private void OnDisable()
    {
        SceneFlowManager.Instance?.Unregister(this);

        if (FishInventoryService.Instance != null)
            FishInventoryService.Instance.OnInventoryChanged -= RefreshUI; // �̺�Ʈ ����

        if (playerCtrls != null)
        {
            playerCtrls.Player.Inventory.performed -= OnInventoryInput; // �Է� ����
            playerCtrls.Disable();
        }
    }

    private void Start()
    {
        inventoryPanelRoot.SetActive(true);

        CreateSlots(quickbarParent, quickbarSlots, inventoryConfig.quickbarSize);
        CreateSlots(inventoryParent, inventorySlots, inventoryConfig.inventorySize);

        inventoryPanelRoot.SetActive(false);

        isSlotsCreated = true;

        if (sharedInventoryData == null && GameManager.Instance != null)
        {
            sharedInventoryData = GameManager.Instance.GetStorageInventoryData();
          //  Debug.Log($"[InventoryUI] Start���� sharedInventoryData �ڵ� ���� �Ϸ�{sharedInventoryData?.name}");
        }

        // ���� ���� �������� ���⼭ ����
        RefreshUI();
    }

    private void ToggleInventory()
    {
        isInventoryOpen = !isInventoryOpen;
        inventoryPanelRoot.SetActive(isInventoryOpen);

        if (isInventoryOpen)
            RefreshUI();
    }

    private void CreateSlots(Transform parent, List<UISlot> list, int size)
    {
        if (slotPrefab == null || parent == null)
        {
          //  Debug.LogError("[InventoryUI] ���� ���� ���� (prefab �Ǵ� parent ����)");
            return;
        }

        for (int i = 0; i < size; i++)
        {
            GameObject newSlot = Instantiate(slotPrefab, parent);
            UISlot slot = newSlot.GetComponent<UISlot>();
            list.Add(slot);
        }

        LayoutRebuilder.ForceRebuildLayoutImmediate(parent.GetComponent<RectTransform>());
    }

    public void RefreshUI()
    {

        if (!isSlotsCreated) return; // ���� ���� �� ȣ�� ���

        if (sharedInventoryData == null)
        {
           // Debug.LogWarning("[InventoryUI] Refresh ���� - storageInventoryData ����");
            return;
        }

        foreach (var quickSlot in quickbarSlots) quickSlot.Clear();
        foreach (var inventorySlot in inventorySlots) inventorySlot.Clear();

        int index = 0;

        foreach (var fish in sharedInventoryData.caughtFishList)
        {
            if (fish == null) continue;

            Sprite icon = FishInventoryService.Instance != null
            ? FishInventoryService.Instance.GetFishSprite(fish.fishType) : null;

            if (icon == null) continue;


            if (index < quickbarSlots.Count)
            {
                quickbarSlots[index].SetItem(icon, fish.fishType, fish.count);
            }
            else
            {
                int inventoryIndex = index - quickbarSlots.Count;
                if (inventoryIndex >= inventorySlots.Count) break;

                inventorySlots[inventoryIndex].SetItem(icon, fish.fishType, fish.count);
            }

            index++;
        }

       // Debug.Log($"[InventoryUI] UI ���ΰ�ħ �Ϸ� ({sharedInventoryData.caughtFishList.Count}��)");
    }

    public void Close()
    {
        isInventoryOpen = false;

        if(inventoryPanelRoot != null)
        {
            inventoryPanelRoot.SetActive(false);
        }   
        
        transform.root.gameObject.SetActive(false);
    }
}
