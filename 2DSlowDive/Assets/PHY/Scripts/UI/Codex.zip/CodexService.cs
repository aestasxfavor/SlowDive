using System.Collections.Generic;
using UnityEngine;


public class CodexService : MonoBehaviour
{
    private CodexSaveData codexSaveData;

    private HashSet<FishType> discoveredFish;

    public bool IsInitialized { get; private set; }

    public void Init(CodexSaveData saveData)
    {
        Debug.Log("[CodexService] Init CALLED");
        codexSaveData = saveData ?? new CodexSaveData();

        if (codexSaveData.codexFishID == null)
        {
            codexSaveData.codexFishID = new List<string>();
        }
        discoveredFish = new HashSet<FishType>();

        foreach (var fishID in codexSaveData.codexFishID)
        {
            if (System.Enum.TryParse(fishID, out FishType type))
            {
                discoveredFish.Add(type);
            }
        }

        IsInitialized = true;
    }

    public bool IsDiscovered(FishType type)
    {
        if (!IsInitialized)
        {
            return false;
        }

        return discoveredFish != null && discoveredFish.Contains(type);
    }

    public bool HasUnViewedNewFish()
    {
        if (!IsInitialized) return false;
        return codexSaveData.hasUnViewedNewFish;
    }

    // Bang: �̱��� ǥ������ ����ǥ
    public void MarkAllBang()
    {
        if (!IsInitialized) return;
        if (!codexSaveData.hasUnViewedNewFish) return;

        codexSaveData.hasUnViewedNewFish = false;
        SaveManager.Instance.SaveCodex();

        Debug.Log("[CodexService] ���� �ű� �˸� ����");
    }

    public bool Registerfish(FishType type)
    {
        if(!IsInitialized) return false;

        // �̹� ��ϵ� �����̸� �ű� �߰� x
        if(discoveredFish.Contains(type))
        {
            Debug.Log($"[CodexService] �̹� ��ϵ� ����: {type}");
            return false;
        }

        // �ű� ���� ��� �������� ��
        if (!discoveredFish.Add(type)) return false;

        codexSaveData.codexFishID.Add(type.ToString());
        codexSaveData.hasUnViewedNewFish = true;

        SaveManager.Instance.SaveCodex();

        Debug.Log(
       $"[CodexService] �ű� ���� ���: {type}, " +
       $"hasUnViewedNewFish = {codexSaveData.hasUnViewedNewFish}"
   );
        return true;
    }

    //public void RegisterFish(FishType type)
    //{
    //    if (!IsInitialized) return;

    //    // 1. �̹� ��ϵƴ��� üũ
    //    if (discoveredFish.Contains(type))
    //    {
    //        Debug.Log("�̹� ��ϵ� ����");
    //        return;
    //    }

    //    // 2. ���� �߰��̸� ���� �߰�
    //    if (!discoveredFish.Add(type)) return;

    //    // 3. CodexSaveData�� �ݿ�
    //    codexSaveData.codexFishID.Add(type.ToString());
    //    codexSaveData.hasUnViewedNewFish = true;
    //    // 4. SaveManager�� ����
    //    SaveManager.Instance.SaveCodex();

    //    Debug.Log($"[CodexService] �ű� ���� ���: {type}, hasUnViewNewFish ={codexSaveData.hasUnViewedNewFish}");
    //}

    public List<CodexViewData> GetCodexViewList()
    {
        var codexViewList = new List<CodexViewData>();

        if (!IsInitialized) return codexViewList;

        int index = 1;

        foreach (FishType type in System.Enum.GetValues(typeof(FishType)))
        {
            bool discovered = IsDiscovered(type);

            Sprite icon = null;

            if (discovered)
            {
                icon = FishInventoryService.Instance.GetFishSprite(type);
            }

            codexViewList.Add(new CodexViewData(type, icon, discovered, index));
            index++;
        }

        return codexViewList;
    }

}
