using UnityEngine;
/// <summary>
/// ���� ���� ������
/// </summary>
[CreateAssetMenu(fileName = "MailDefinition", menuName = "Scriptable Objects/MailDefinition")]
public class MailDefinition : ScriptableObject
{
    [Header("ID (Save Key)")]
    [SerializeField] private string mailId = "M001";

    [Header("UI")]
    [SerializeField] private string listTitle;  // ��ư��
    [SerializeField] private string title;      // ���� ����

    [TextArea(6, 20)]
    [SerializeField] private string body;

    public string MailId => mailId;

    public string ListTitle => string.IsNullOrWhiteSpace(listTitle) ? title : listTitle;
    public string Title => title;
    public string Body => body;
}
